How to check the results:

it's on google app machines. I am kinda lazy to apply my own account. Just borrow ones from the vision group in Bath. University. 
Thanks to Dr. Yizhe Song.


http://graphicsurveyapp.appspot.com/backup?experiment=4

the id, can be changed from 1 -- 10, (if I'm right).

