% Choose the best mixture of Gaussian classifier you have, compare this
% mixture of Gaussian classifier with the neural network you implemented in
% the last assignment. 


% Train neural network classifier. The number of hidden units should be
% equal to the number of mixture components. 

% Show the error rate comparison.

%-------------------- Add your code here --------------------------------