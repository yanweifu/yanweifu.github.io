environment needed:
1. Python 3.7.1
2. Pytorch 1.0.0
3. Numpy

In the submission process,  we only provide .pyc file; thus  the version of Python should be restricted.

The source codes will be released upon the acceptance; and then we do not need to restrict the python version.

To start with our toolbox, 

Just try:

python3 train_lenet.py