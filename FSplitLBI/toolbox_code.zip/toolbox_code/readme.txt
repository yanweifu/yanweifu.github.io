environment needed:
1. Python 3.7.1
2. Pytorch 1.0.0
3. Numpy
Currently due to we only provide .pyc file, the version of Python is restricted,
 when we give the source code, this restrict will not exist.